rm -r * ./
